The attached file solution.cpp follows the instructions laid out in M472_S25_P1.pdf.
To compile, use `g++ -std=c++17 solution.cpp -o solution`. To run the program, use ./solution.
I've also attached the output of the program in the file output.txt.
